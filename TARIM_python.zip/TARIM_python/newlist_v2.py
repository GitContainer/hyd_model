#!/usr/bin/python
# -*- coding: utf-8 -*-

urun = open("urun.txt").readlines()
list_1 = open("1_04.txt").readlines()
list_2 = open("2_06.txt").readlines()
list_3 = open("3_08.txt").readlines()
list_4 = open("4_1.txt").readlines()

list_4 = [w.replace('Ç','c') for w in list_4]

count = 0
with open("newfile.txt", "a") as newfile:
    for m in urun:
        u = m.strip()
        for n in list_1:
            l1 = n.strip().upper()
            if u in l1 and count == 0:
                count = 1
                newfile.write(u+","+"0.4" "\n")
                break
        for w in list_2:
            l2 = w.strip().upper()
            if u in l2 and count == 0:
                count = 1
                newfile.write(u+","+"0.6" "\n")
                break
        for x in list_3:
            l3 = x.strip().upper()
            if u in l3 and count == 0:
                count = 1
                newfile.write(u+","+"0.8" "\n")
                break

        for q in list_4:
            l4 = q.strip().upper()
            if u in l4 and count == 0:
                count = 1
                newfile.write(u+","+"1.0" "\n")
                break
        if count != 1:   
                newfile.write("KENDIN BAK\n")
        count = 0
    
